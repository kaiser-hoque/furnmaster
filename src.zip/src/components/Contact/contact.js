import React from 'react'
import Header from '../Header/header'
import Footer from '../Footer/footer'
const contact = () => {
    return (
        <div>     
                   
        </div>
    )
}

export default contact